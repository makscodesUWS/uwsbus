    from flask import Flask, render_template, request, redirect, session
    import random

    app = Flask(__name__)
    app.secret_key = 'your_secret_key'  # Set a secret key for session management

    # Simulated user database (in a real app, use a database)
    users = {
        'parent1': 'password1',
        'parent2': 'password2',
    }

    @app.route('/')
    def home():
        if 'logged_in' in session and session['logged_in']:
            return redirect('/child_status')
        else:
            return render_template('home.html')  # Render the home page

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']

            if username in users and users[username] == password:
                session['logged_in'] = True
                session['username'] = username
                return redirect('/child_status')
            else:
                return render_template('login.html', error='Invalid username or password')
        else:
            return render_template('login.html')

    @app.route('/child_status')
    def child_status():
        if 'logged_in' in session and session['logged_in']:
            # In a real app, fetch child data from a database using session['username']
            child_name = 'John Doe'  # Replace with actual data
            child_status = f"Child: {child_name}, Status: {random.choice(['Present', 'Absent', 'Late'])}"
            return render_template('child_status.html', child_status=child_status)
        else:
            return redirect('/login')

    @app.route('/logout')
    def logout():
        session.pop('logged_in', None)
        session.pop('username', None)
        return redirect('/')  # Redirect back to the home page after logout

    if __name__ == '__main__':
        app.run(debug=True)